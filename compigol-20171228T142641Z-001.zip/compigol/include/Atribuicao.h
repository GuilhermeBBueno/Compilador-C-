#ifndef ATRIBUICAO_H
#define ATRIBUICAO_H

#include "Identificadores.h"
#include "Instrucoes.h"

class Atribuicao :public Instrucao_atr
{
    public:
        Identificador ident;
        Expressoes expr;
};
#endif // ATRIBUICAO_H
