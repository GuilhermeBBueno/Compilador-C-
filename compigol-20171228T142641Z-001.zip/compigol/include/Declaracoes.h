#ifndef DECLARACOES_H
#define DECLARACOES_H

#include "Portugol.h"

class Declaracoes
{
    public:
};

class Declaracao :public Declaracoes
{
    public:
        char* tipo;
        Identificadores idents;
};

class Declaracao_r :public Declaracoes
{
    public:
        Declaracao d1;
        Declaracoes d2;
};
#endif // DECLARACOES_H
