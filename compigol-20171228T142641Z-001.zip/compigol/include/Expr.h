#ifndef EXPR_H
#define EXPR_H

#include "Lexer.h"
#include "Node.h"

class Expr : public Node
{
    public:
};
#endif // EXPR_H
