#ifndef EXPRESSOES_H
#define EXPRESSOES_H

#include "Operador.h"
#include "Identificadores.h"

class Expressoes
{
    public:
};

class Expressao : public Expressoes
{
    public:
};

class Expressao_r : public Expressoes
{
    public:
        Expressao expr1;
        Operador oper;
        Expressao expr2;
};

class Expressao_int : public Expressao
{
    public:
        char* inteiro;
};

class Expressao_real : public Expressao
{
    public:
        char* real;
};
class Expressao_ident : public Expressao
{
    public:
        Identificador ident;
        void getIdent()
        {

        }
};
#endif // EXPRESSAO_H
