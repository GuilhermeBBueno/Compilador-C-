#ifndef IDENTIFICADORES_H
#define IDENTIFICADORES_H

#include "Portugol.h"

class Identificadores
{
    public:
};

class Identificador :public Identificadores
{
    public:
        char* ident;
};

class Identificador_r :public Identificadores
{
    public:
        Identificador ident1;
        Identificadores ident2;
};
#endif // IDENTIFICADORES_H
