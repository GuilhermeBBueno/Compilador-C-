#ifndef INSTRUCOES_H
#define INSTRUCOES_H

#include "Atribuicao.h"
#include "Expressao.h"
#include "Identificadores.h"

class Instrucoes
{
    public:
};

class Instrucao : public Instrucoes
{
    public:
};

class Instrucao_r : public Instrucoes
{
    public:
        Instrucao inst1;
        Instrucoes inst2;
};

class Instrucao_atr : public Instrucao
{
    public:

};

class Instrucao_se : public Instrucao
{
    public:
};

class Instrucao_se_a : public Instrucao_se
{
    public:
        Expressoes exprs;
        Instrucoes insts;
};

class Instrucao_se_b : public Instrucao_se
{
    public:
        Expressoes exprs;
        Instrucoes insts1;
        Instrucoes insts2;
};

class Instrucao_para : public Instrucao
{
    public:
        Identificador ident;
        Expressao expr1;
        Expressao expr2;
        Instrucoes insts;
};

class Instrucao_enquanto : public Instrucao
{
    public:
        Expressoes exprs;
        Instrucoes insts;
};

class Instrucao_leitura : public Instrucao
{
    public:
        Identificador ident;
};

class Instrucao_escrita : public Instrucao
{
    public:
};

class Instrucao_escrita_a : public Instrucao_escrita
{
    public:
        char* text;
};

class Instrucao_escrita_b : public Instrucao_escrita
{
    public:
        Expressao expr;
};
#endif // INSTRUCOES_H
