#include "Lexer.h"
Token elementAt(list<Token>& tokens, int index)
{
    if(tokens.size() > index)
    {
        list<Token>::iterator it = tokens.begin();
        std::advance(it, index);
        return *it;
    }
}

Token NovoToken(ClasseToken tipo, char* info, int linha)
{
    Token novo;
    novo.linha = linha;
    novo.tipo = tipo;
    novo.info = new char[strlen(info)+ 1];
    novo.info = info;

    return novo;
}

Token NovoToken(ClasseToken tipo, char* info)
{
    Token novo;
    novo.linha = 0;
    novo.tipo = tipo;
    novo.info = new char[strlen(info)+ 1];
    novo.info = info;

    return novo;
}

//imprime no arquivo Lexer.txt os tokens do arquivo portugol
int ImprimeArquivo ( list<Token>* tokens)
{
    ofstream file;
    file.open("Lexer.txt");
    if(!file.is_open())
    {
        perror ("Lexer.txt nao foi possivel criar o arquivo.");
        return -1;
    }
    for(std::list<Token>::iterator it = (*tokens).begin(); it != (*tokens).end(); ++it)
    {
        switch((*it).tipo)
        {
                case Identif:
                    file << "\nIdentificador"<<" -> " << (*it).info;
                    cout << "\nIdentificador"<<" -> " << (*it).info;
                    break;
                case Texto:
                    file << "\nTexto" <<" -> " << (*it).info;
                    cout << "\nTexto" <<" -> " << (*it).info;
                    break;
                case Inteiro:
                    file << "\nInteiro" <<" -> " << (*it).info;
                    cout << "\nInteiro" <<" -> " << (*it).info;
                    break;
                case Real:
                    file << "\nReal" <<" -> " << (*it).info;
                     cout << "\nReal" <<" -> " << (*it).info;
                    break;
                case OpAritmetico:
                    file << "\nOperador" <<" -> " << (*it).info;
                    cout << "\nOperador" <<" -> " << (*it).info;
                    break;
                case OpAtribuidor:
                    file << "\nAtribuicao" <<" -> " << (*it).info;
                    cout << "\nAtribuicao" <<" -> " << (*it).info;
                    break;
                case Delimitador:
                    file << "\nDelimitador" <<" -> " << (*it).info;
                    cout << "\nDelimitador" <<" -> " << (*it).info;
                    break;
                case PalavraChave:
                    file << "\nPalavra Chave" <<" -> " << (*it).info;
                    cout << "\nPalavra Chave" <<" -> " << (*it).info;
                    break;
                case Invalido:
                    file << "\nInvalido" <<" -> " << (*it).info;
                    cout << "\nInvalido" <<" -> " << (*it).info;
                    break;
                case FimDeArquivo:
                    file << "\nFim de Arquivo" <<" -> " << (*it).info;
                    cout << "\nFim de Arquivo" <<" -> " << (*it).info;
                    break;
        }

    }
    cout << "\n\//////////////////****************//////////////////";
    file.close();
    return 0;
}


//Faz a varredura da lista de token e altera o tipo das palavras identificadoras para Booleano ou PalavrasChave
int ScanPalavrasChave ( list<Token>* tokens )
{
    int tamanho = 0;
    tamanho = (*tokens).size();
    if(tamanho = 0)
        return -2;
    else
    {
        for(std::list<Token>::iterator it = (*tokens).begin(); it != (*tokens).end(); ++it)
        {
            if((*it).tipo == Identif)
            {
                if(strcmp((*it).info, "PROGRAMA") == 0 ||
                   strcmp((*it).info ,  "INTEIRO") == 0 ||
                   strcmp((*it).info ,  "REAL") == 0  ||
                   strcmp((*it).info ,  "VARIAVEIS") == 0 ||
                   strcmp((*it).info , "INICIO" ) == 0 ||
                   strcmp((*it).info  , "FIM" ) == 0 ||
                   strcmp((*it).info ,  "LEIA") == 0  ||
                   strcmp((*it).info  , "IMPRIMA") == 0  )
                {
                    (*it).tipo = PalavraChave;
#ifdef DEBUG_SCAN
                    cout << "\n Tipo de " << (*it).info << " trocada para PalavraChave";
#endif
                }
            }
        }
    }
    return 0;
}

//Faz a varredura do arquivo e gera a lista de tokens
int Scan(char* FilePath, list<Token>& tokens)
{
    ifstream file;
    char ch;
    string aux;
    int countLine = 1;
    int countRealPoint = 0;

    file.open(FilePath);
    cout << endl;
    if(!file.is_open())
    {
        perror (FilePath);
        return -1;
    }

    // enquanto n�o � o fim do arquivo fa�a
    while(!file.eof())
    {
        //reinicializa aux
        aux.clear();
        ch = (char)file.peek();
        if(ch == -1)
            break;

        int estado = 0;
        //Soma cada linha nova
        if(ch == '\n')
            countLine++;
        //checa se � um caracter de tabula��o ou espa�o
        if(isspace((int)ch) /*|| isblank((int)ch)*/ )
            file.get();
        //se for letra mudar o estado para 1
        else if(isalpha((int)ch))
            estado = 1;
        //se for um numero mudar para estado 2
        else if(isdigit((int)ch)|| ch == '-')
            estado = 2;
        //se for um texto mudar para estado 3
        else if (ch == '"')
            estado = 3;
        //se for um coment�rio mudar para estado 4
        else if (ch =='/')
            estado = 4;
        //se for um operador de atribui��o mudar para estado 5
        else if (ch == '=')
            estado = 5;
        else
            estado = 6;
        switch(estado)
        {
            //ESTADO 1 - RECONHECE UM IDENTIFICADOR
            case 1:
            {
                int i = 0;
                while (isdigit(ch) ||  isalpha(ch) )
                {
                    aux += ch;
                    file.get();

                    if(file.peek() == -1)
                        break;
                    else
                        ch =  (char)file.peek();
                }
                Token novo;
                novo.linha = countLine;
                novo.tipo = Identif;
                novo.info = new char[aux.length() + 1];
                strcpy(novo.info,aux.c_str());

                tokens.push_back(novo);
#ifdef DEBUG
                cout << "\n Identificador: " << aux;
#endif
            }
            break;

            //ESTADO 2 - RECONHECE UM INTEIRO
            case 2:
            {
                if(ch == '-')
                {
                    aux += ch;
                    file.get();
                    if(file.peek() == -1)
                        break;
                    else
                        ch = (char)file.peek();
                }
                while(isdigit(ch))
                {
                    aux+=ch;
                    file.get();

                    if(file.peek() == '.' && countRealPoint == 0)
                    {
                        aux+=file.peek();
                        file.get();
                        countRealPoint++;
                    }

                    if(file.peek() == -1)
                        break;
                    else
                        ch = file.peek();
                }
				if(aux == "-")
                {
                        Token novo;
                        novo.linha = countLine;
                        novo.tipo = OpAritmetico;
                        novo.info = "-";
                        tokens.push_back(novo);
#ifdef DEBUG
                        cout << "\n OpAritmetico: " << aux;
#endif
                }
                else
                {
                    if(countRealPoint == 1)
                    {
                        Token novo;
                        novo.linha = countLine;
                        novo.tipo = Real;
                        novo.info = new char[aux.length() + 1];
                        strcpy(novo.info,aux.c_str());
                        tokens.push_back(novo);
                        countRealPoint = 0;
                    }
                    else if(countRealPoint > 1)
                    {
                        Token novo;
                        novo.linha = countLine;
                        novo.tipo = Invalido;
                        novo.info = new char[aux.length() + 1];
                        strcpy(novo.info,aux.c_str());
                        tokens.push_back(novo);
                        break;                    }
                    else
                    {
                        Token novo;
                        novo.linha = countLine;
                        novo.tipo = Inteiro;
                        novo.info = new char[aux.length() + 1];
                        strcpy(novo.info,aux.c_str());
                        tokens.push_back(novo);
                    }
#ifdef DEBUG
                    cout << "\n Inteiro: " << aux;
#endif
                }
            }
            break;

            //ESTADO 3 - RECONHECE TEXTOS
            case 3:
            {
                file.get();
                if( file.peek() == -1)
                    break;
                else
                    ch = (char)file.peek();
                while (ch != '"')
                {
                    aux += ch;
                    file.get();
                    if(file.peek() == -1)
                        break;
                    else
                        ch = (char)file.peek();
                }
                file.get();
                Token novo;
                novo.linha = countLine;
                novo.tipo = Texto;
                novo.info = new char[aux.length() + 1];
                strcpy(novo.info,aux.c_str());
                tokens.push_back(novo);
#ifdef DEBUG
                cout << "\n Texto: " << aux;
#endif
            }
            break;

            //ESTADO 4 - RECONHECE COMENT�RIOS /* E //
            case 4:
            {
                file.get();
                aux += ch;
                if(file.peek() == -1)
                    break;
                else
                    ch = (char)file.peek();

                if ( ch == '/' )
                {
                    file.get();
                    if(file.peek() == -1)
                        break;
                    else
                        ch = (char)file.peek();
                    while(ch != '\n')
                    {
                        file.get();
                        if(file.peek() == -1)
                            break;
                        else
                            ch = (char)file.peek();
                    }
                }
                else if( ch == '*')
                {
                    int estado_comentario = 0;
                    while(estado_comentario != 3)
                    {
                        if(file.peek() == -1)
                            break;
                        else
                            ch = (char)file.peek();
                        if( ch == '*')
                            estado_comentario = 1;
                        else
                            estado_comentario = 2;
                        switch(estado_comentario)
                        {
                        case 1:
                            {
                                file.get();
                                if(file.peek() == -1)
                                    break;
                                else
                                    ch = (char)file.peek();
                                if( ch == '/')
                                {
                                    estado_comentario = 3;
                                    file.get();
                                }
                            }
                            break;
                        case 2:
                            {
                                file.get();
                                if(file.peek() == -1)
                                    break;
                                else
                                    ch = (char)file.peek();
                                while( ch != '*' )
                                {
                                    file.get();
                                    if(file.peek() == -1)
                                        break;
                                    else
                                        ch = (char)file.peek();
                                }
                                break;
                            }
                        }
                    }

                }
                else
                {
                    file.get();
                    if(file.peek() != -1)
                        ch = file.peek();
                    Token novo;
                    novo.linha = countLine;
                    novo.tipo = OpAritmetico;
                    novo.info = "/";
                    tokens.push_back(novo);
#ifdef DEBUG
                    cout << "\n OpAritmetico: " << aux;
#endif
                }
            }
            break;
            //ESTADO 5 - RECONHECE OPERADOR DE ATRIBUI��O
            case 5:
            {
               file.get();
               Token novo;
               novo.linha = countLine;
               novo.tipo = OpAtribuidor;
               novo.info = "=";
               tokens.push_back(novo);
    #ifdef DEBUG
                    cout << "\n OpAtribuicao: = ";
    #endif
            }
            break;

            //ESTADO 6 - RECONHECE UM CARACTER ESPECIAL
            case 6:
            {
                switch(ch)
                {
                    case ':':
                    {
                        file.get();
                        Token novo;
                        novo.linha = countLine;
                        novo.tipo = Delimitador;
                        novo.info = ":";
                        tokens.push_back(novo);
#ifdef DEBUG
                        cout << "\n Dois pontos: " << ch;
#endif
                    }
                    break;
                    case ',':
                    {
                        file.get();
                        Token novo;
                        novo.linha = countLine;
                        novo.tipo = Delimitador;
                        novo.info = ",";
                        tokens.push_back(novo);
#ifdef DEBUG
                        cout << "\n Virgula: " << ch;
#endif
                    }
                    break;
                    case ';':
                    {
                        file.get();
                        Token novo;
                        novo.linha = countLine;
                        novo.tipo = Delimitador;
                        novo.info = ";";
                        tokens.push_back(novo);
#ifdef DEBUG
                        cout << "\n Ponto e virgula: " << ch;
#endif
                    }
                    break;
                    case '+':
                    {
                        file.get();
                        Token novo;
                        novo.linha = countLine;
                        novo.tipo = OpAritmetico;
                        novo.info = "+";
                        tokens.push_back(novo);
#ifdef DEBUG
                        cout << "\n OpAritmetico: " << ch;
#endif
                    }
                    break;
                    case '*':
                    {
                        file.get();
                        Token novo;
                        novo.linha = countLine;
                        novo.tipo = OpAritmetico;
                        novo.info = "*";
                        tokens.push_back(novo);
#ifdef DEBUG
                        cout << "\n OpAritmetico: " << ch;
#endif
                    }
                    break;
                    default:
                    {
                        file.get();
                        Token novo;
                        novo.linha = countLine;
                        novo.tipo = Invalido;
                        novo.info = new char[2];
                        strcpy(novo.info,"");
                        novo.info[0] = ch;
                        novo.info[1] = '\0';
                        tokens.push_back(novo);
                        cout<< "\n Erro na analise lexica!Caracter Invalido: "<< ch<<"\n";
                        return -3;
                    }
                    break;
                }
            }
            break;

        }
    }

    file.close();

    //finaliza percorrendo a lista e alterando o tipo das palavras reservadas
#ifdef DEBUG
    cout << "\n\nScanPalavrasChave";
#endif
    if ( ScanPalavrasChave(&tokens) != 0 )
        return -2;
#ifdef DEBUG
    cout << "\n\nImprimeArquivo";
#endif
    if ( ImprimeArquivo(&tokens) != 0 )
        return -1;
    return 0;
}

