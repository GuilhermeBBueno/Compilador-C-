#ifndef LEXER_H_INCLUDED
#define LEXER_H_INCLUDED

#include <iostream>
#include <fstream>
#include <stdio.h>
#include <ctype.h>
#include <list>
#include <string.h>

using namespace std;

enum ClasseToken
{
    Identif,
    Texto,
    Inteiro,
    Real,
    OpAritmetico,
    OpAtribuidor,
    Delimitador,
    PalavraChave,
    Invalido,
    FimDeArquivo
};

typedef struct
{
    ClasseToken tipo;
    char* info;
    int linha;
}Token;

Token NovoToken(ClasseToken tipo, char* info, int linha);
Token NovoToken(ClasseToken tipo, char* info);
//imprime no arquivo output.txt os tokens do arquivo portugol
int ImprimeArquivo ( list<Token>* tokens);

//imprime no arquivo output.txt os tokens do arquivo portugol
int ImprimeArquivo ( list<Token>* tokens, char* fileName);

//Faz a varredura da lista de token e altera o tipo das palavras identificadoras para Booleano ou PalavrasChave
int ScanPalavrasChave ( list<Token>* tokens );

//Faz a varredura do arquivo e gera a lista de tokens
int Scan(char* FilePath, list<Token>& token);

Token elementAt(list<Token>& tokens, int index);

#endif // ANALISADORLEXICO_H_INCLUDED
