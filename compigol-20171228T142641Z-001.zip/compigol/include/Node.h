#ifndef NODE_H
#define NODE_H

#include <iostream>
#include <fstream>
#include <stdio.h>
#include <ctype.h>
#include <list>
#include <string.h>
#include <stdlib.h>
#include "Lexer.h"

using namespace std;

class Node {
    public:
        int Labels = 0;
        int posicao = 0;
        ofstream file;
        list<int> printed;
        char codigos[1000][100];
        char* arqSaida = "Inter.txt";
        int newlabel() { return ++Labels;}
        void start()
        {
            file.open(arqSaida);
            file.clear();
            file.close();
        }
        int emitlabel(int i)
        {
            char cod[100];

            strcpy(cod, "Linha");
            char numi[5];
            itoa(i,numi,10);
            strcat(cod, numi);
            strcat(cod,":");
            strcpy(codigos[i],cod);

            int pos = i-1;
            file.close();
            return pos;
        }
        void emit(char* s)
        {
            file.open(arqSaida, std::ios::app);
            if(!file.is_open())
            {
                perror ("\nInter.txt nao foi possivel criar o arquivo. ");
                return;
            }
            strcat(codigos[++posicao],"\t");
            strcat(s,"\n");
            strcat(codigos[posicao],s);
            file.close();
        }
        void emit(char* s, long pos)
        {
            file.open(arqSaida,std::ios::app);
            if(!file.is_open())
            {
                perror ("\nInter.txt nao foi possivel criar o arquivo. ");
                return;
            }
            strcat(codigos[pos],"\t");
            strcat(codigos[pos],s);
            file.close();
        }

        bool notPrinted(int guarda)
        {
            for(std::list<int>::iterator it = printed.begin(); it != printed.end(); ++it)
            {
                if( *it == guarda )
                {
                    return false;
                }
            }
            printed.push_back(guarda);
            return true;
        }

        void setnotPrinted(int guarda)
        {
            for(std::list<int>::iterator it = printed.begin(); it != printed.end(); ++it)
            {
                if( *it == guarda )
                {
                    *it = 0;
                }
            }
        }
        void print()
        {
            ofstream arquivoSaida;
            arquivoSaida.open(arqSaida);
            if(!arquivoSaida.is_open())
            {
                perror ("\nInter.txt nao foi possivel criar o arquivo.");
                return;
            }
            else
            {
                cout << "\n";
                cout << "\n//////////////////****************//////////////////";
                cout<< "\nCodigo intermediario:\n";
                for(int j = 1; j <= Labels; j++)
                {
                        arquivoSaida << codigos[j];
                        cout<< codigos[j];
                }
            }
            arquivoSaida.close();
        }
};
#endif // NODE_H
