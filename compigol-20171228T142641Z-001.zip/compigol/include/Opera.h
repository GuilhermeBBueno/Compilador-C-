#ifndef OPERA_H
#define OPERA_H

#include "include/Expr.h"

class Opera : public Expr
{
    public:
        Opera(Token tok, ClasseToken p) { setExpr(tok, p); }
        Expr reduce()
        {
            Expr *x = gen();
            Temp *t = new Temp();
            char c[100];
            c[0] = '\0';
            strcat( c , t.toString());
            strcat( c , " = ");
            strcat( c, x.toString() );
            return c;
        }
    protected:
    private:
};
#endif // OPERA_H
