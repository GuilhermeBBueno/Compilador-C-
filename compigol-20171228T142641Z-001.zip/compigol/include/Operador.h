#ifndef OPERADOR_H
#define OPERADOR_H

class Operador
{
    public:
};

class Operador_aritmetico : public Operador
{
    public:
        char* oper_ari;
};
#endif // OPERADOR_H
