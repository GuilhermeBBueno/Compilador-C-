#include "Parser.h"

Parser::Parser(list<Token>& tokens)
{
	Tokens = tokens;
	Tokens.push_back(NovoToken(FimDeArquivo,"$"));
	codigo.start();
	index = 0;
	CarregaPalavrasReservadas(PalavrasReservadas);
	Parse();
}

Parser::~Parser()
{
}

void Parser::CarregaPalavrasReservadas(list<char*>& palavrasReservadas)
{
	palavrasReservadas.push_back("INTEIRO");
	palavrasReservadas.push_back("REAL");
	palavrasReservadas.push_back("PROGRAMA");
	palavrasReservadas.push_back("VARIAVEIS");
	palavrasReservadas.push_back("INICIO");
	palavrasReservadas.push_back("FIM");
	palavrasReservadas.push_back("LEIA");
	palavrasReservadas.push_back("IMPRIMA");
}

void Parser::Parse()
{
    if (portugol() && elementAt(Tokens,index).tipo == FimDeArquivo)
	{
		cout << "\n\nAnalise sintatica realizada com sucesso!!";
		//imprime codigo intermediario no terminal
		codigo.print();
	}
	else
	{
		cout << "\n\nErro na analise sintatica!\n";
	}

}
bool Parser::portugol()
{
	if(compare("PROGRAMA"))
	{
		index++;
		Identificador ident;
		if(identificador(&ident))
		{
			result.ident = ident;
			if(compare(";"))
			{
				index++;
				if(compare("VARIAVEIS"))
				{
					index++;
					Declaracoes decls;
					if(declaracoes(&decls))
					{
						result.decls = decls;
						if(compare("INICIO"))
						{
						    codigo.emitlabel(codigo.newlabel());
							index++;
							Instrucoes insts;
							if(instrucoes(&insts))
							{
								result.insts = insts;
								if(compare("FIM"))
								{
									index++;
									return true;
								}
							}
						}
					}
				}
			}
		}
	}
	return false;
}
/*
bool Parser::semantico(){
char x;
if (tipo()){
    index++;
    x = elementAt(Tokens,index).info;
}
return false;
}
*/
bool Parser::declaracoes(Declaracoes* decls)
{
	int guarda = index;
	Declaracao_r decls_r;
	if(declaracao(&decls_r.d1))
	{
		if(declaracao_r(&decls_r.d2))
		{
			decls = &decls_r;
			return true;
		}
	}

	index = guarda;
	Declaracao decl;
	if(declaracao(&decl))
	{
		decls = &decl;
		return true;
	}
	return false;
}

bool Parser::declaracao_r(Declaracoes* declr_r)
{
	int guarda = index;
	Declaracao_r decls;
	if(declaracao(&decls.d1))
	{
		if(declaracao_r(&decls.d2))
		{
			declr_r = &decls;
			return true;
		}
	}

	index = guarda;
	Declaracao decl;

	if(declaracao(&decl))
	{
		declr_r = &decl;
		return true;
	}
	return false;
}

bool Parser::declaracao(Declaracao* decl)
{
	if(tipo())
	{
		(*decl).tipo = elementAt(Tokens, index).info;
		index++;

		if ( strcmp(elementAt(Tokens, index).info,":") == 0) //eles s�o iguais quando strcmp retorna 0
		{
			index++;
			if(identificadores(&decl->idents))
			{
				if(strcmp(elementAt(Tokens,index).info, ";") == 0)
				{
					index++;
					return true;
				}
				else
				{
					cout << "\n\nDeclaracao: \';\' esperado! LINHA:" << elementAt(Tokens, index).linha;
				}
			}
		}
		else
		{
			cout <<"\n\nDeclaracao: \':\' esperado! LINHA:" << elementAt(Tokens, index).linha;
		}
	}
	return false;
}

bool Parser::identificadores(Identificadores* idents)
{
	int guarda = index;
	Identificador_r ident_r;
	if (identificador(&ident_r.ident1))
	{
		if (identificador_r(&ident_r.ident2))
		{
			idents = &ident_r;
			return true;
		}
	}

	index = guarda;
	Identificador ident;
	if (identificador(&ident))
	{
		idents = &ident;
		return true;
	}

	return false;
}

bool Parser::identificador_r(Identificadores* idents)
{
	int guarda = index;
	if (strcmp(elementAt(Tokens,index).info,",")==0)
	{
		index++;

		Identificador_r ident_r;

		if (identificador(&ident_r.ident1))
		{
			if (identificador_r(&ident_r.ident2))
			{
				idents = &ident_r;
				return true;
			}
		}
	}

	index = guarda;

	if (strcmp(elementAt(Tokens,index).info,",")==0)
	{
		index++;

		Identificador ident;

		if (identificador(&ident))
		{
			idents = &ident;
			return true;
		}
	}

	return false;
}

bool Parser::identificador(Identificador* ident)
{
	if(elementAt(Tokens,index).tipo == Identif && !checkPalavrasReservadas(elementAt(Tokens,index).info))
		//TODO
	{
		(*ident).ident = elementAt(Tokens,index).info;
		index++;
		return true;
	}
	return false;
}

bool Parser::instrucoes(Instrucoes* insts)
{
	int guarda = index;
	Instrucao_r inst_r;
	if (instrucao(&inst_r.inst1))
	{
		if (instrucao_r(&inst_r.inst2))
		{
			insts = &inst_r;
			return true;
		}
	}

	index = guarda;
	Instrucao inst;
	if (instrucao(&inst))
	{
		insts = &inst;
		return true;
	}

	return false;
}

bool Parser::instrucao_r(Instrucoes* insts)
{
	int guarda = index;
	Instrucao_r inst_r;

	if (instrucao(&inst_r.inst1))
	{
		if (instrucao_r(&inst_r.inst2))
		{
			insts = &inst_r;
			return true;
		}
	}

	index = guarda;

	Instrucao inst;

	if (instrucao(&inst))
	{
		insts = &inst;
		return true;
	}

	return false;
}

bool Parser::instrucao(Instrucao* inst)
{
	int guarda = index;
	Atribuicao atr;
	if (atribuicao(&atr))
	{
		inst = &atr;
		if(codigo.notPrinted(guarda))
        {
            AtrReduce(guarda);
        }
		return true;
	}

	index = guarda;
	Instrucao_leitura inst_leitura;
	if (instrucao_leitura(&inst_leitura))
	{
		inst = &inst_leitura;
		if(codigo.notPrinted(guarda))
        {
        InstReduce(guarda);
        }
		return true;
	}

	index = guarda;
	Instrucao_escrita inst_escrita;
	if (instrucao_escrita(&inst_escrita))
	{
		inst = &inst_escrita;
		if(codigo.notPrinted(guarda))
        {
          InstReduce(guarda);
        }
		return true;
	}

	return false;
}


void Parser::AtrReduce(int guarda)
{
    char s[100];
    strcpy(s,"=, ");
    strcat(s,elementAt(Tokens, guarda).info);
    strcat(s,", ");
    strcat(s,t.lastString());
    codigo.emit(s);
    t.conta = 0;
    int i = codigo.newlabel();
    codigo.emitlabel(i);
}
void Parser::InstReduce(int guarda)
{
    char s[100];
    strcpy(s,"");
    strcat(s,elementAt(Tokens, guarda).info);
    strcat(s,", ");
    strcat(s,elementAt(Tokens, guarda+1).info);
    codigo.emit(s);
    t.conta = 0;
    int i = codigo.newlabel();
    codigo.emitlabel(i);

}

bool Parser::atribuicao(Atribuicao* atr)
{
	Identificador ident;
	int guarda;
	if(identificador(&ident))
	{
		(*atr).ident = ident;
		if(strcmp(elementAt(Tokens,index).info, "=") == 0 )
		{
		    guarda = index-1;
			index++;
			Expressoes expr;
			if(expressoes(&expr))
			{
				(*atr).expr = expr;
				if(strcmp(elementAt(Tokens,index).info, ";") == 0)
				{
					index++;
					return true;
				}
				else
				{
					cout << "\n\nDeclaracao: \';\' esperado! LINHA:" << elementAt(Tokens, index).linha;
				}
			}
		}
		else
		{
			cout <<"\n\nDeclaracao: \'=\' esperado! LINHA: " << elementAt(Tokens, index).linha;
		}
	}
	return false;
}

bool Parser::instrucao_leitura(Instrucao_leitura* inst_leitura)
{
	Instrucao_leitura inst_lei;
	if(compare("LEIA"))
	{
		index++;
		Identificador ident;
		if(identificador(&ident))
		{
			inst_lei.ident = ident;
			if(compare(";"))
			{
				index++;
				inst_leitura = &inst_lei;
				return true;
			}
			else
			{
				cout << "\n\nDeclaracao: \';\' esperado! LINHA:" << elementAt(Tokens,index).linha;
			}
		}
		else
		{
			cout << "\n\n Identificador esperado! LINHA:" << elementAt(Tokens,index).linha;
		}
	}
	return false;
}

bool Parser::instrucao_escrita(Instrucao_escrita* inst_escrita)
{
	Instrucao_escrita_a inst_esc_a;
	Instrucao_escrita_b inst_esc_b;
	if(compare("IMPRIMA"))
	{
		index++;

		if(elementAt(Tokens, index).tipo == Texto)
		{
			inst_esc_a.text = elementAt(Tokens, index).info;
			index++;
			if(compare(";"))
			{
				index++;
				inst_escrita = &inst_esc_a;

				return true;
			}
			else
			{
				cout << "\n\nDeclaracao: \';\' esperado! LINHA:" << elementAt(Tokens,index).linha;
			}
		}
		Expressao expr;
		if(expressao(&expr))
		{
			inst_esc_b.expr = expr;
			if(compare(";"))
			{
				index++;
				inst_escrita = &inst_esc_b;
				return true;
			}
			else
			{
				cout << "\n\nDeclaracao: \';\' esperado! LINHA:" << elementAt(Tokens,index).linha;
			}
		}
		cout << "\n\n Texto ou expressao esperado! LINHA:" << elementAt(Tokens,index).linha;
	}
	return false;
}

void Parser::ExprReduce(int guarda)
{
    if(elementAt(Tokens,guarda+1).tipo == OpAritmetico)
    {
        int i = codigo.newlabel();
        char s[100];
        if(t.Conta() == 0)
        {
            strcpy(s,elementAt(Tokens, guarda+1).info);
            strcat(s,", ");
            strcat(s,elementAt(Tokens, guarda).info);
            strcat(s,", ");
            strcat(s,elementAt(Tokens, guarda+2).info);
            strcat(s,", ");
            strcat(s,t.toString());
            codigo.emit(s);
            codigo.emitlabel(i);
        }
        else
        {
            strcpy(s,elementAt(Tokens, guarda+1).info);
            strcat(s,", ");
            strcat(s,t.lastString());
            strcat(s,", ");
            strcat(s,elementAt(Tokens, guarda).info);
            strcat(s,", ");
            strcat(s,t.toString());
            codigo.emit(s);
            codigo.emitlabel(i);
        }
    }
    else if(elementAt(Tokens,guarda+1).tipo == Delimitador)
    {
        int i = codigo.newlabel();
        char s[100];
        codigo.emitlabel(i);
        strcpy(s,"=, ");
        strcat(s,elementAt(Tokens, guarda-2).info);
        strcat(s,", ");
        strcat(s,elementAt(Tokens, guarda).info);
        codigo.notPrinted(guarda-2);
        codigo.emit(s);
        codigo.emitlabel(i);
    }
}

bool Parser::expressoes(Expressoes* expr)
{
	int guarda = index;
	Expressao_r expr_r;
	int tipo = 0;

	if(expressao(&expr_r.expr1))
	{
		if(operador(&expr_r.oper))
		{
			if(expressao_r(&expr_r.expr2))
			{
				expr = &expr_r;
				if(codigo.notPrinted(guarda))
                {
                    ExprReduce(guarda);
                }
				return true;
			}
		}
	}

	index = guarda;
	Expressao_ident expr_ident;
	if(identificador(&expr_ident.ident))
	{
		expr = &expr_ident;
        if(codigo.notPrinted(guarda))
        {
            ExprReduce(guarda);
        }
		return true;
	}

	index = guarda;
	Expressao_int expr_int;
	if(elementAt(Tokens,index).tipo == Inteiro)
	{
		expr_int.inteiro = elementAt(Tokens,index).info;
		expr = &expr_int;
        if(codigo.notPrinted(guarda))
        {
            ExprReduce(guarda);
        }
		index++;
		return true;
	}
    index = guarda;
	Expressao_real expr_real;
	if(elementAt(Tokens,index).tipo == Real)
	{
		expr_real.real = elementAt(Tokens,index).info;
		expr = &expr_real;
        if(codigo.notPrinted(guarda))
        {
            ExprReduce(guarda);
        }
		index++;
		return true;
	}
	return false;
}

bool Parser::expressao_r(Expressoes* expr)
{
	int guarda = index;
	Expressao_r expr_r;
	if(expressao(&expr_r.expr1))
	{
		if(operador(&expr_r.oper))
		{
			if(expressao_r(&expr_r.expr2))
			{
				expr = &expr_r;
                if(codigo.notPrinted(guarda))
                {
                    ExprReduce(guarda);
                }
				return true;
			}
		}
	}

	index = guarda;
	Expressao_ident expr_ident;
	if(identificador(&expr_ident.ident))
	{
		expr = &expr_ident;
		return true;
	}

	index = guarda;
	Expressao_int expr_int;
	if(elementAt(Tokens,index).tipo == Inteiro)
	{
		expr_int.inteiro = elementAt(Tokens,index).info;
		expr = &expr_int;
		index++;
		return true;
	}

	index = guarda;
	Expressao_real expr_real;
	if(elementAt(Tokens,index).tipo == Real)
	{
		expr_real.real = elementAt(Tokens,index).info;
		expr = &expr_real;
		index++;
		return true;
	}

	return false;
}

bool Parser::expressao(Expressao* expr)
{
	int guarda = index;
	Expressao_ident expr_ident;
	if(identificador(&expr_ident.ident))
	{
		expr = &expr_ident;
		return true;
	}

	index = guarda;
	Expressao_int expr_int;
	if(elementAt(Tokens,index).tipo == Inteiro)
	{
		expr_int.inteiro = elementAt(Tokens,index).info;
		expr = &expr_int;
		index++;
		return true;
	}

	index = guarda;
	Expressao_real expr_real;
	if(elementAt(Tokens,index).tipo == Real)
	{
		expr_real.real = elementAt(Tokens,index).info;
		expr = &expr_int;
		index++;
		return true;
	}
	return false;
}

bool Parser::operador(Operador* oper)
{
	int guarda = index;
	Operador_aritmetico oper_ari;
	if(operador_aritmetico(&oper_ari))
	{
		oper = &oper_ari;
		return true;
	}

	return false;
}

bool Parser::operador_aritmetico(Operador_aritmetico* oper_ari)
{
	if(elementAt(Tokens,index).tipo == OpAritmetico)
	{
		(*oper_ari).oper_ari = elementAt(Tokens, index).info;
		index++;
		return true;
	}
	return false;
}

bool Parser::tipo()
{
	if(strcmp(elementAt(Tokens, index).info, "INTEIRO") == 0)
		return true;
    if(strcmp(elementAt(Tokens, index).info, "REAL") == 0)
		return true;
	return false;
}
bool Parser::instrucao1()
{
	if(strcmp(elementAt(Tokens, index).info, "LEIA") == 0)
		return true;
    if(strcmp(elementAt(Tokens, index).info, "IMPRIMA") == 0)
		return true;
	return false;
}


bool Parser::compare(char* palavraTeste)
{
	if(strcmp(elementAt(Tokens,index).info,palavraTeste)==0)
		return true;
	else
		return false;
}

bool Parser::checkPalavrasReservadas(char* info)
{
	for(std::list<char*>::iterator it = PalavrasReservadas.begin(); it != PalavrasReservadas.end(); ++it)
	{
		if(strcmp((char*)(*it),info) == 0 )
		{
			return true;
		}
	}
	return false;
}
