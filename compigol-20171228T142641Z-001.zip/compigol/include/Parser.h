#ifndef PARSER_H
#define PARSER_H

#include "Portugol.h"
#include "Lexer.h"
#include "Temp.h"

class Parser
{
    public:
        int index;
        list<Token> Tokens;
        Portugol result;
        Node codigo;
        Temp t;
        list<char*> PalavrasReservadas;

        Parser(list<Token>& tokens);
        virtual ~Parser();

        list<Token> GetTokens() { return Tokens; }
        void SetTokens(list<Token>& val) { Tokens = val; }

        Portugol Getresult() { return result; }

        list<char*> GetPalavrasReservadas() { return PalavrasReservadas; }
        void SetPalavrasReservadas(list<char*> val) { PalavrasReservadas = val; }

        void CarregaPalavrasReservadas(list<char*>& palavrasReservadas);

        bool compare(char* palavraTeste); // compara char* com o token atual

        //m�todos e fun��es
    private:
        void ExprReduce(int guarda);
        void InstReduce(int guarda);
        void AtrReduce(int guarda);
        void Parse();
		bool portugol();
		bool instrucao1();
        bool declaracoes(Declaracoes* decls);
        bool declaracao_r(Declaracoes* declr_r);
        bool declaracao(Declaracao* decl);
        bool identificadores(Identificadores* idents);
        bool identificador_r(Identificadores* idents);
        bool identificador(Identificador* ident);
        bool instrucoes(Instrucoes* insts);
        bool instrucao_r(Instrucoes* insts);
        bool instrucao(Instrucao* inst);
        bool atribuicao(Atribuicao* atr);
		bool instrucao_leitura(Instrucao_leitura* inst_leitura);
		bool instrucao_escrita(Instrucao_escrita* inst_escrita);
		bool expressoes(Expressoes* expr);
        bool expressao(Expressao* expr);
		bool expressao_r(Expressoes* expr);
        bool operador(Operador* oper);
        bool operador_aritmetico(Operador_aritmetico* oper_ari);
        bool tipo();
        bool checkPalavrasReservadas(char* info);
};
#endif // PARSER_H
