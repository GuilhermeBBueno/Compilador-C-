#ifndef PORTUGOL_H
#define PORTUGOL_H

#include "Expressao.h"
#include "Declaracoes.h"
#include "Atribuicao.h"
#include "Instrucoes.h"
#include "Identificadores.h"
#include "Operador.h"

class Portugol
{
    public:
        Identificador ident;
        Declaracoes decls;
        Instrucoes insts;
};
#endif //PORTUGOL_H
