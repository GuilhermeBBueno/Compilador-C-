#ifndef STMT_H
#define STMT_H

#include "include/Node.h"

class Stmt : public Node
{
    public:
        Stmt() {}
        static Stmt Null = new Stmt();

        void gen(int b, int a) {}

        int after = 0;
        static Stmt Enclosing = Stmt.Null;
    protected:
    private:
};
#endif // STMT_H
