#ifndef TEMP_H
#define TEMP_H

#include "stdlib.h"
#include "Expr.h"

class Temp : public Expr
{
    public:
        int conta = 0;
        char cont[10];
        int Conta() { return conta; }
        char* lastString() { return cont;}
        char* toString()
        {
            char c[30];
            itoa(++conta, c, 10);
            char c2[32];
            strcpy(c2, "t") ;
            strcat(c2,c);
            strcpy(cont, c2);
            return c2;
        }
};
#endif // TEMP_H
