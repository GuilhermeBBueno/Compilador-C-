#include "include/Lexer.h"
#include "include/Parser.h"

int main(int argc, char *argv[])
{
    char filepath[100];
    list<Token> tokens;

    if ( argc != 2)
    {
        cout << "\n|TRABALHO DE COMPILADORES|\n";
        cout << "\nProf Kleber Jacques Ferreira de Souza\n";
        cout << "\nGuilherme Augusto Bueno Borba";
        cout << "\nJose Nilson dos Santos Junior";
        cout << "\nLarissa de Souza Barcelos";
        cout << "\nLucas Viana Dias Carvalho\n\n";
        cout << "\n\tEntre com o nome do arquivo texto de extensao .por: ";
        cin >> filepath;
    }
    else
    {
        strcpy(filepath,argv[1]);
    }
    int error=Scan(filepath, tokens);
    if(error>=0)
    Parser* s = new Parser(tokens);

    return 0;
}
